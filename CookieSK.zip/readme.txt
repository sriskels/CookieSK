-- ENG --
Installation:
1. Extract .zip file to plugins/Skript/scripts
2. Start server
3. See to console

-- PL --
Instalacja:
1. Wypakuj plik .zip do plugins/Skript/scripts
2. W��cz serwer
3. Sprawd� konsole, aby zobaczy� czy dodatek si� za�adowa�